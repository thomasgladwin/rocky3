//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "uMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
TForm1::cSynapse::cSynapse()
{
        nSynapseTypes = 0;
        nSynapses = 0;
        g = 0;
        tauX = 0;
        tauS = 0;
        x = 0;
        s = 0;
        xDecay = 0;
        sDecay = 0;
        tauSInv = 0;
        epsQuick = pow(10, -6);
}
TForm1::cSynapse::~cSynapse()
{
        if (nSynapses != 0)
        {
                delete [] nSynapses;
                delete [] tauX;
                delete [] tauS;
                delete [] g;
                delete [] x;
                delete [] s;
                delete [] xDecay;
                delete [] sDecay;
                delete [] tauSInv;
        }
}
void TForm1::cSynapse::setDefaults(float timeStep)
{
        // 0 - AMPA
        // 1 - NMDA
        // 2 - GABA
        // 3, 4, 5... - AMPA until needed
        if (nSynapseTypes == 0)
        {
                return;
        }
        // units are always 10 ^0
        float
                milli = 0.001;
        // voltage dependence
        Mg = 1;
        // potential
        VE = 0;
        VI = -70 * milli;
        // time constants: x
        if (tauX != 0)
        {
                delete [] tauX;
        }
        tauX = new float[nSynapseTypes];
        for (int t = 0; t < nSynapseTypes; t++)
        {
                switch (t)
                {
                        case 0:
                                tauX[t] = 0.5 * milli;
                                break;
                        case 1:
                                tauX[t] = 2 * milli;
                                break;
                        case 2:
                                tauX[t] = 0 * milli;
                                break;
                        default:
                                tauX[t] = 0.5 * milli;
                                break;
                }
        }
        // time constants: s
        if (tauS != 0)
        {
                delete [] tauS;
        }
        tauS = new float[nSynapseTypes];
        for (int t = 0; t < nSynapseTypes; t++)
        {
                switch (t)
                {
                        case 0:
                                tauS[t] = 2 * milli;
                                break;
                        case 1:
                                tauS[t] = 80 * milli;
                                break;
                        case 2:
                                tauS[t] = 10 * milli;
                                break;
                        default:
                                tauS[t] = 2 * milli;
                                break;
                }
        }
        // kinetics variables
        phi = 1;
        alphaX = phi * 1;
        alphaS = phi * 1.0 / milli;
        alphaI = phi * 0.9;
        // acceleration vars
        xDecay = new float[nSynapseTypes];
        for (int st = 0; st < nSynapseTypes; st++)
        {
                if (tauX[st] == 0)
                {
                        xDecay[st] = 0;
                        continue;
                }
                float
                        Bx = phi / tauX[st];
                xDecay[st] = exp(-Bx * timeStep);
        }
        sDecay = new float[nSynapseTypes];
        for (int st = 0; st < nSynapseTypes; st++)
        {
                if (tauS[st] == 0)
                {
                        sDecay[st] = 0;
                        continue;
                }
                float
                        Bs = phi / tauS[st];
                sDecay[st] = exp(-Bs * timeStep);
        }
        if (tauSInv != 0)
        {
                delete [] tauSInv;
        }
        tauSInv = new float[nSynapseTypes];
        for (int t = 0; t < nSynapseTypes; t++)
        {
                if (tauS[t] == 0)
                {
                        tauSInv[t] = 0;
                }
                else
                {
                        tauSInv[t] = 1 / tauS[t];
                }
        }
}
void TForm1::cSynapse::clear()
{
        // x, s, g
        if (x != 0)
        {
                for (int iSynapse = 0; iSynapse < nSynapsesTotal; iSynapse++)
                {
                        delete [] x[iSynapse];
                }
                delete [] x;
                x = 0;
        }
        if (s != 0)
        {
                for (int iSynapse = 0; iSynapse < nSynapsesTotal; iSynapse++)
                {
                        delete [] s[iSynapse];
                }
                delete [] s;
                s = 0;
        }
        if (g != 0)
        {
                for (int iSynapse = 0; iSynapse < nSynapsesTotal; iSynapse++)
                {
                        delete [] g[iSynapse];
                }
                delete [] g;
                g = 0;
        }
        if (xDecay != 0)
        {
                delete [] xDecay;
                xDecay = 0;
        }
        if (sDecay != 0)
        {
                delete [] sDecay;
                sDecay = 0;
        }
        if (tauSInv != 0)
        {
                delete [] tauSInv;
                tauSInv = 0;
        }
}
void TForm1::cSynapse::init(int anSynapsesTotal, int anSynapseTypes,
        int *anSynapses, float timeStep)
{
        nSynapsesTotal = anSynapsesTotal;
        nSynapseTypes = anSynapseTypes;
        if (nSynapses != 0)
        {
                delete [] nSynapses;
        }
        nSynapses = new int[nSynapseTypes];
        for (int t= 0; t < nSynapseTypes; t++)
        {
                nSynapses[t] = anSynapses[t];
                if (nSynapses[t] == 0)
                {
                        nSynapses[t] = 1;
                }
        }
        clear();
        // x: derivative-of-s
        x = new float*[nSynapsesTotal];
        for (int iSynapse = 0; iSynapse < nSynapsesTotal; iSynapse++)
        {
                x[iSynapse] = new float[nSynapseTypes];
                for (int t = 0; t < nSynapseTypes; t++)
                {
                        x[iSynapse][t] = 0;
                }
        }
        // s: fraction of open channels
        s = new float*[nSynapsesTotal];
        for (int iSynapse = 0; iSynapse < nSynapsesTotal; iSynapse++)
        {
                s[iSynapse] = new float[nSynapseTypes];
                for (int t = 0; t < nSynapseTypes; t++)
                {
                        s[iSynapse][t] = 0;
                }
        }
        // g: conductance
        g = new float*[nSynapsesTotal];
        for (int iSynapse = 0; iSynapse < nSynapsesTotal; iSynapse++)
        {
                g[iSynapse] = new float[nSynapseTypes];
                for (int t = 0; t < nSynapseTypes; t++)
                {
                        g[iSynapse][t] = 0;
                }
        }
        setDefaults(timeStep);
}
float TForm1::cSynapse::integrateAMPASpike(int iSynapse, float Vm, float timeStep, bool spike, int type)
{
        if (spike == false && x[iSynapse][type] <= epsQuick && s[iSynapse][type] <= epsQuick)
        {
                return 0;
        }
        x[iSynapse][type] = x[iSynapse][type] * xDecay[type];
        if (spike)
        {
                x[iSynapse][type] += phi * alphaX;
        }
        float
                As = alphaS * x[iSynapse][type],
                Bs = alphaS * x[iSynapse][type] + tauSInv[type],
                thisExp = exp(-Bs * timeStep);
        s[iSynapse][type] = s[iSynapse][type] * thisExp + (As / Bs) * (1 - thisExp);
        /*
        float
                dxdt = -phi * x[type] / tauX[type];
        if (spike)
        {
                x[type] += phi * alphaX;
        }
        x[type] += dxdt * timeStep;
        if (x[type] < 0 || x[type] > 1)
        {
                x[type] = 0;
        }
        float
                dsdt = phi * (alphaS * x[type] * (1 - s[type]) - s[type] / tauS[type]);
        s[type] += dsdt * timeStep;
        */
        float
                I = g[iSynapse][type] * s[iSynapse][type] * (Vm - VE);
        return I;
}
float TForm1::cSynapse::integrateNMDASpike(int iSynapse, float Vm, float timeStep, bool spike, int type)
{
        if (spike == false && x[iSynapse][type] <= epsQuick && s[iSynapse][type] <= epsQuick)
        {
                return 0;
        }
        x[iSynapse][type] = x[iSynapse][type] * xDecay[type];
        if (spike)
        {
                x[iSynapse][type] += alphaX;
        }
        float
                A = alphaS * x[iSynapse][type],
                B = alphaS * x[iSynapse][type] + tauSInv[type];
        float
                thisExp = exp(-B * timeStep);
        s[iSynapse][type] = s[iSynapse][type] * thisExp + (A / B) * (1 - thisExp);
        /*
        float
                dxdt = -phi * x[type] / tauX[type];
        if (spike)
        {
                x[type] += phi * alphaX;
        }
        x[type] += dxdt * timeStep;
        if (x[type] < 0)
        {
                x[type] = 0;
        }
        float
                dsdt = phi * (alphaS * x[type] * (1 - s[type]) - s[type] / tauS[type]);
        s[type] += dsdt * timeStep;
        */
        float
                voltDep = 1.0 / (1.0 + Mg * exp(-62 * Vm) / 3.57), // Jahr & Stevens, 1990
                I = g[iSynapse][type] * s[iSynapse][type] * (Vm - VE) * voltDep;
        return I;
}
float TForm1::cSynapse::integrateGABASpike(int iSynapse, float Vm, float timeStep, bool spike, int type)
{
        if (spike == false && x[iSynapse][type] <= epsQuick && s[iSynapse][type] <= epsQuick)
        {
                return 0;
        }
        float
                spikeEffect = 0;
        if (spike)
        {
                spikeEffect = alphaI * (1 - s[iSynapse][type]);
        }
        s[iSynapse][type] = s[iSynapse][type] * sDecay[type];
        s[iSynapse][type] += spikeEffect;
        /*
        float
                dsdt = -s[type] / tauS[type];
        if (spike)
        {
                s[type] += alphaI * (1 - s[type]);
        }
        s[type] += dsdt * timeStep;
        */
        float
                I = g[iSynapse][type] * s[iSynapse][type] * (Vm - VI);
        return I;
}
//---------------------------------------------------------------------------
TForm1::cAbstractNeuron::cAbstractNeuron()
{
        synapses = 0;
        setDefaults();
}
TForm1::cAbstractNeuron::~cAbstractNeuron()
{
        if (synapses != 0)
        {
                delete synapses;
        }
}
void TForm1::cAbstractNeuron::setDefaults()
{
        // units are always 10 ^0
        spiking = false;
        nSynapseTypes = 0;
        float
                milli = 0.001,
                micro = pow(10, -6),
                nano = pow(10, -9);
        // potentials
        VL = -70 * milli;
        Vth = -52 * milli,
        Vreset = -59 * milli;
        Vm = VL;
        // capacitance
        Cm = 0.5 * nano;
        // conductances
        gL = 0.025 * micro;
        // time constants:
        tauRef = 2 * milli;
        // nasty variables
        lastSpikeTime = -1;
        timeStep = 1; // adjusted instead of tau's
}
void TForm1::cAbstractNeuron::init(float samplingRate, int anSynapseTypes,
        int anNeurons, int * anSynapses)
{
        nNeurons = anNeurons;
        nSynapseTypes = anSynapseTypes;
        adjustTimeConstants(samplingRate);
        int
                totalNSynapses = nNeurons;
        nSynapses = totalNSynapses;
        if (totalNSynapses == 0)
        {
                return;
        }
        if (synapses != 0)
        {
                delete [] synapses;
        }
        synapses = new cSynapse;
        float
                timeStep = 1.0 / samplingRate;
        synapses->init(totalNSynapses, nSynapseTypes, anSynapses, timeStep);
}
void TForm1::cAbstractNeuron::adjustTimeConstants(float samplingRate)
{
        timeStep = 1.0 / samplingRate; //
}
float TForm1::cAbstractNeuron::newMembranePotential(int *nSpikes, int ** source,
        float time, float afferent, float ** & weights)
{
        // calculates Vm at next sample-point
        float
                I = 0,
                dV;
        I += leakage();
        I += integrateInputs(nSpikes, source, afferent, weights);
        dV = I / Cm;
        Vm += dV * timeStep;
        // not if - else, as synaptic kinetics must be updated as well as Vm
        if (time - lastSpikeTime <= tauRef && lastSpikeTime >= 0)
        {
                Vm = Vreset;
        }
        if (Vm > Vth)
        {
                spiking = true;
                Vm = Vreset;
        }
        return Vm;
}
float TForm1::cAbstractNeuron::leakage()
{
        float
                I = -gL * (Vm - VL);
        return I;
}
float TForm1::cAbstractNeuron::integrateInputs(int *nSpikes,
        int ** source, float afferent, float ** & weights)
{
        float
                I = 0;
        for (int t = 0; t < nSynapseTypes; t++)
        {
                float
                        thisI;
                switch (t)
                {
                        case 0:
                                thisI = integrateAMPAInputs(nSpikes[t], source[t], t,
                                        weights);
                                break;
                        case 1:
                                thisI = integrateNMDAInputs(nSpikes[t], source[t], t,
                                        weights);
                                break;
                        case 2:
                                thisI = integrateGABAInputs(nSpikes[t], source[t], t,
                                        weights);
                                break;
                        default:
                                thisI = integrateAMPAInputs(nSpikes[t], source[t], t,
                                        weights);
                                break;
                }
                I -= thisI;
        }
        I += afferent;
        return I;
}
float TForm1::cAbstractNeuron::integrateAMPAInputs(int nSpikes, int *source,
        int type, float ** & weights)
{
        int
                iSpike = 0;
        float
                I = 0;
        for (int iSynapse = 0; iSynapse < nSynapses; iSynapse++)
        {
                bool
                        spike = false;
                if (iSpike < nSpikes)
                {
                        if (iSynapse == source[iSpike])
                        {
                                iSpike++;
                                spike = true;
                        }
                }
                float
                        thisI = synapses->integrateAMPASpike(iSynapse, Vm, timeStep, spike, type);
                if (weights[iSynapse][type] > 0)
                {
                        I += weights[iSynapse][type] * thisI;
                }
        }
        return I;
}
float TForm1::cAbstractNeuron::integrateNMDAInputs(int nSpikes, int *source, int type,
        float ** & weights)
{
        int
                iSpike = 0;
        float
                I = 0;
        for (int iSynapse = 0; iSynapse < nSynapses; iSynapse++)
        {
                bool
                        spike = false;
                if (iSpike < nSpikes)
                {
                        if (iSynapse == source[iSpike])
                        {
                                iSpike++;
                                spike = true;
                        }
                }
                float
                        thisI = synapses->integrateNMDASpike(iSynapse, Vm, timeStep, spike, type);
                if (weights[iSynapse][type] > 0)
                {
                        I += weights[iSynapse][type] * thisI;
                }
        }
        return I;
}
float TForm1::cAbstractNeuron::integrateGABAInputs(int nSpikes, int *source, int type,
        float ** & weights)
{
        int
                iSpike = 0;
        float
                I = 0;
        for (int iSynapse = 0; iSynapse < nSynapses; iSynapse++)
        {
                bool
                        spike = false;
                if (iSpike < nSpikes)
                {
                        if (iSynapse == source[iSpike])
                        {
                                iSpike++;
                                spike = true;
                        }
                }
                float
                        thisI = synapses->integrateGABASpike(iSynapse, Vm, timeStep, spike, type);
                if (weights[iSynapse][type] > 0)
                {
                        I += weights[iSynapse][type] * thisI;
                }
        }
        return I;
}
float TForm1::cAbstractNeuron::fire(float time)
{
        if (spiking)
        {
                spiking = false;
                lastSpikeTime = time;
                return 1;
        }
        else
        {
                return 0;
        }
}
//---------------------------------------------------------------------------
TForm1::cPyramidalNeuron::cPyramidalNeuron()
{
}
TForm1::cPyramidalNeuron::~cPyramidalNeuron()
{
}
//---------------------------------------------------------------------------
TForm1::cInhibitoryNeuron::cInhibitoryNeuron()
{
        setDefaults();
        setInhibitoryDefaults();
}
TForm1::cInhibitoryNeuron::~cInhibitoryNeuron()
{
}
void TForm1::cInhibitoryNeuron::setInhibitoryDefaults()
{
        float
                milli = 0.001,
                micro = pow(10, -6),
                nano = pow(10, -9);
        // constants different from AMPA neurons
        Cm = 0.2 * nano;
        gL = 0.02 * micro;
        VL = -65 * milli;
        Vreset = -60 * milli;
        tauRef = 1 * milli;
}
//---------------------------------------------------------------------------
TForm1::cNeuronHolder::cNeuronHolder()
{
        neuron = 0;
}
TForm1::cNeuronHolder::~cNeuronHolder()
{
        if (neuron != 0)
        {
                delete neuron;
        }
}
//---------------------------------------------------------------------------
TForm1::cSynapticEvent::cSynapticEvent()
{
        nSpikes = 0;
        source = 0;
        windowLength = 0;
}
TForm1::cSynapticEvent::~cSynapticEvent()
{
        clear();
}
void TForm1::cSynapticEvent::clear()
{
        if (nSpikes != 0)
        {
                for (int iSample = 0; iSample < windowLength; iSample++)
                {
                        delete [] nSpikes[iSample];
                }
                delete [] nSpikes;
                nSpikes = 0;
        }
        if (source != 0)
        {
                for (int iSample = 0; iSample < windowLength; iSample++)
                {
                        for (int i = 0; i < nSynapseTypes; i++)
                        {
                                if (source[iSample][i] != 0)
                                {
                                        delete [] source[iSample][i];
                                }
                        }
                        delete [] source[iSample];
                }
                delete [] source;
                source = 0;
        }
}
void TForm1::cSynapticEvent::init(int awindowLength, int anSynapseTypes)
{
        clear();
        windowLength = awindowLength + 1; // fire() places event at sample + dSample
        nSynapseTypes = anSynapseTypes;
        // nSpikes array
        nSpikes = new int*[windowLength];
        for (int iSample = 0; iSample < windowLength; iSample++)
        {
                nSpikes[iSample] = new int[nSynapseTypes];
                for (int st = 0; st < nSynapseTypes; st++)
                {
                        nSpikes[iSample][st] = 0;
                }
        }
        source = new int**[windowLength];
        for (int i = 0; i < windowLength; i++)
        {
                source[i] = new int*[nSynapseTypes];
                for (int st = 0; st < nSynapseTypes; st++)
                {
                        source[i][st] = 0;
                }
        }
}
int TForm1::cSynapticEvent::add(int iSample, int synapseType, int newSource)
{
        // iSample == delay
        if (iSample >= windowLength)
        {
                return -1;
        }
        // update sources
        int
                *temp = 0;
        if (nSpikes[iSample][synapseType] > 0)
        {
                temp = new int[nSpikes[iSample][synapseType]];
        }
        for (int i = 0; i < nSpikes[iSample][synapseType]; i++)
        {
                temp[i] = source[iSample][synapseType][i];
        }
        if (source[iSample][synapseType] != 0)
        {
                delete [] source[iSample][synapseType];
        }
        source[iSample][synapseType] = new int[nSpikes[iSample][synapseType] + 1];
        for (int i = 0; i < nSpikes[iSample][synapseType]; i++)
        {
                source[iSample][synapseType][i] = temp[i];
        }
        if (temp != 0)
        {
                delete [] temp;
        }
        source[iSample][synapseType][nSpikes[iSample][synapseType]] = newSource;
        // update nSpikes
        nSpikes[iSample][synapseType]++;
        return nSpikes[iSample][synapseType];
}
void TForm1::cSynapticEvent::shift()
{
        for (int iSample = 0; iSample < windowLength - 1; iSample++)
        {
                for (int st = 0; st < nSynapseTypes; st++)
                {
                        nSpikes[iSample][st] = nSpikes[iSample + 1][st];
                        delete [] source[iSample][st];
                        source[iSample][st] = new int[nSpikes[iSample][st]];
                        for (int iSpike = 0; iSpike < nSpikes[iSample][st]; iSpike++)
                        {
                                source[iSample][st][iSpike] = source[iSample + 1][st][iSpike];
                        }
                }
        }
        for (int st = 0; st < nSynapseTypes; st++)
        {
                nSpikes[windowLength - 1][st] = 0;
                source[windowLength - 1][st] = 0; // mem must not be deleted!
        }
}
//---------------------------------------------------------------------------
TForm1::cStimulation::cStimulation()
{
        nEvents = 0;
        start = 0;
        stop = 0;
        val = 0;
}
TForm1::cStimulation::~cStimulation()
{
        if (nEvents > 0)
        {
                delete [] start;
                delete [] stop;
                delete [] val;
        }
}
void TForm1::cStimulation::init(int anEvents, int *astart, int *astop, float *aval)
{
        if (nEvents > 0)
        {
                delete [] start;
                start = 0;
                delete [] stop;
                stop = 0;
                delete [] val;
                val = 0;
        }
        nEvents = anEvents;
        start = astart;
        stop = astop;
        val = aval;
        for (int iEvent = 0; iEvent < nEvents; iEvent++)
        {
                val[iEvent] *= pow(10, -9);
        }
}
void TForm1::cStimulation::initOsc(int nFreqs, float * freq, float * duration, float *aval,
        int nSamples, float samplingRate)
{
        if (nEvents > 0)
        {
                delete [] start;
                start = 0;
                delete [] stop;
                stop = 0;
                delete [] val;
                val = 0;
        }
        nEvents = 0;
        for (int iF = 0; iF < nFreqs; iF++)
        {
                float
                        time = (float)nSamples / samplingRate;
                nEvents += ceil(time * freq[iF]);
        }
        if (nEvents > 0)
        {
                start = new int[nEvents];
                stop = new int[nEvents];
                val = new float[nEvents];
        }
        else
        {
                return;
        }
        int
                iEvent = 0;
        for (int iSample = 0; iSample < nSamples; iSample++)
        {
                for (int iF = 0; iF < nFreqs; iF++)
                {
                        int
                                period = ceil(samplingRate / freq[iF]); // [in samples]
                        if (iSample % period == 0)
                        {
                                start[iEvent] = iSample;
                                val[iEvent] = aval[iF] * pow(10, -9);
                                float
                                        pulseStop = iSample + duration[iF];
                                if (pulseStop >= nSamples)
                                {
                                        pulseStop = nSamples - 1;
                                }
                                stop[iEvent] = pulseStop;
                                iEvent++;
                        }
                }
        }
}
float TForm1::cStimulation::stimulation(int sample)
{
        for (int iEvent = 0; iEvent < nEvents; iEvent++)
        {
                if (start[iEvent] <= sample && stop[iEvent] > sample)
                {
                        return val[iEvent];
                }
        }
        return 0;
}
//---------------------------------------------------------------------------
TForm1::cModules::cModules()
{
        nModules = 0;
        nMembers = 0;
        memberNeurons = 0;
        nMembersOfType = 0;
        delay = 0;
        delaysd = 0;
        pIn = 0;
        pNext = 0;
        pOut = 0;
        p = 0;
        stimulation = 0;
        maxDelaySamples = 0;
}
TForm1::cModules::~cModules()
{
        clear();
}
void TForm1::cModules::clear()
{
        for (int i = 0; i < 3; i++)
        {
                delete [] pIn;
                delete [] pNext;
                delete [] pOut;
        }
        if (nModules > 0)
        {
                delete [] nMembers;
                delete [] memberNeurons;
                for (int i = 0; i < nModules; i++)
                {
                        for (int j = 0; j < nModules; j++)
                        {
                                delete [] p[i][j];
                                delete [] w[i][j];
                                delete [] delay[i][j];
                                delete [] delaysd[i][j];
                        }
                        delete [] p[i];
                        delete [] w[i];
                        delete [] delay[i];
                        delete [] delaysd[i];
                }
                delete [] p;
                delete [] w;
                delete [] delay;
                delete [] delaysd;
        }
        if (nMembersOfType != 0)
        {
                for (int t = 0; t < nNeuronTypes; t++)
                {
                        delete [] nMembersOfType[t];
                }
                delete [] nMembersOfType;
        }
        if (stimulation != 0)
        {
                delete [] stimulation;
        }
}
void TForm1::cModules::init(int anModules, int * anMembers, int ** anMembersOfType,
        int ** amemberNeurons, float *apIn, float *apNext, float *apOut,
        int anSynapseTypes, int anNeuronTypes)
{
        clear();
        nModules = anModules;
        nSynapseTypes = anSynapseTypes;
        nNeuronTypes = anNeuronTypes;
        if (nMembers != 0)
        {
                delete nMembers;
        }
        stimulation = new cStimulation[nModules];
        nMembers = anMembers;
        nMembersOfType = anMembersOfType;
        memberNeurons = amemberNeurons;
        pIn = apIn;
        pNext = apNext;
        pOut = apOut;
        p = new float**[nModules];
        w = new float**[nModules];
        delay = new float**[nModules];
        delaysd = new float**[nModules];
        for (int i = 0; i < nModules; i++)
        {
                p[i] = new float*[nModules];
                w[i] = new float*[nModules];
                delay[i] = new float*[nModules];
                delaysd[i] = new float*[nModules];
                for (int j = 0; j < nModules; j++)
                {
                        p[i][j] = new float[nSynapseTypes];
                        w[i][j] = new float[nSynapseTypes];
                        delay[i][j] = new float[nSynapseTypes];
                        delaysd[i][j] = new float[nSynapseTypes];
                        for (int k = 0; k < nSynapseTypes; k++)
                        {
                                if (i == j)
                                {
                                        p[i][j][k] = pIn[k];
                                }
                                else if (i == j - 1)
                                {
                                        p[i][j][k] = pNext[k];
                                }
                                else
                                {
                                        p[i][j][k] = pOut[k];
                                }
                                w[i][j][k] = 1.0;
                                delay[i][j][k] = 0;
                                delaysd[i][j][k] = 0;
                        }
                }
        }
}
bool TForm1::cModules::setConnection(int mod1, int mod2, float *ap)
{
        if (mod1 >= nModules || mod2 >= nModules || mod1 < 0 || mod2 < 0)
        {
                return false;
        }
        for (int t = 0; t < nSynapseTypes; t++)
        {
                p[mod1][mod2][t] = ap[t];
        }
        return true;
}
void TForm1::cModules::normalizeWeights()
{
        for (int i = 0; i < nModules; i++)
        {
                for (int k = 0; k < nSynapseTypes; k++)
                {
                        int
                                neuronType = 0;
                        if (k == 2)
                        {
                                neuronType = 1;
                        }
                        float
                                nIncoming = 0;
                        for (int j = 0; j < nModules; j++)
                        {
                                nIncoming += nMembersOfType[neuronType][j] * p[j][i][k];
                                if (i == j)
                                {
                                        nIncoming -= p[j][i][k];
                                }
                        }
                        for (int j = 0; j < nModules; j++)
                        {
                                if (w[j][i][k] * nIncoming == 0)
                                {
                                        continue;
                                }
                                w[j][i][k] /= (nIncoming);
                        }
                }
        }
}
bool TForm1::cModules::setWeight(int mod1, int mod2, float *aw)
{
        if (mod1 >= nModules || mod2 >= nModules || mod1 < 0 || mod2 < 0)
        {
                return false;
        }
        for (int t = 0; t < nSynapseTypes; t++)
        {
                w[mod1][mod2][t] = aw[t];
        }
        return true;
}
void TForm1::cModules::setDelay(int modFrom, int modTo, int st, float adelay, float adelaysd)
{
        if (!(modFrom < 0 || modFrom >= nModules ||
                modTo < 0 || modTo >= nModules ||
                st < 0 || st >= nSynapseTypes))
        {
                delay[modFrom][modTo][st] = adelay / 1000.0;
                delaysd[modFrom][modTo][st] = adelaysd / 1000.0;
        }
}
int TForm1::cModules::moduleOf(int iNeuron)
{
        int
                mod = -1;
        for (int iMod = 0; iMod < nModules; iMod++)
        {
                for (int i = 0; i < nMembers[iMod]; i++)
                {
                        if (iNeuron == memberNeurons[iMod][i])
                        {
                                mod = iMod;
                                break;
                        }
                }
                if (mod == iMod)
                {
                        break;
                }
        }
        return mod;
}
int TForm1::cModules::member(int iMember, int iModule)
{
        int
                neuronIndex = memberNeurons[iModule][iMember];
        return neuronIndex;
}
void TForm1::cModules::setStimulation(int stimMod, int anEvents,
        int *start, int *stop, float *val)
{
        if (stimMod < 0 || stimMod >= nModules)
        {
                return;
        }
        stimulation[stimMod].init(anEvents, start, stop, val);
}
void TForm1::cModules::setOscStimulation(int stimMod, int anFreqs, float *freq,
        float * duration, float *val, int nSamples, float samplingRate)
{
        if (stimMod < 0 || stimMod >= nModules)
        {
                return;
        }
        stimulation[stimMod].initOsc(anFreqs, freq, duration, val,
                nSamples, samplingRate);
}
//---------------------------------------------------------------------------
TForm1::cNetwork::cNetwork()
{
        DecimalSeparator = '.';
        potentialHistoryName = "rocky3.pot";
        spikingHistoryName = "rocky.spi";
        afferentsName = "rocky3.aff";
        infoFileName = "rocky3.inf";
        weightsFileName = "rocky3.wei";
        conductanceFileName = "rocky3.con";
        // soft-code
        setDefaults();
}
TForm1::cNetwork::~cNetwork()
{
        clear();
        if (modules != 0)
        {
                delete modules;
        }
        if (nOfNeuronType != 0)
        {
                delete [] nOfNeuronType;
        }
        if (affM != 0)
        {
                delete [] affM;
                delete [] affSD;
        }
        if (affLambda != 0)
        {
                delete [] affLambda;
                delete [] affIL;
                delete [] affI0;
                delete [] affTau;
        }
}
void TForm1::cNetwork::clear()
{
        // clears data that get initialized per network run;
        // i.e., not nOfNeuronType, modules etc.
        // if it doesn't get init'd, it gets set during parsing.
        delete [] neurons;
        for (int iNeuron = 0; iNeuron < nNeurons; iNeuron++)
        {
                for (int iN2 = 0; iN2 < nNeurons; iN2++)
                {
                        delete [] weights[iNeuron][iN2];
                }
                delete [] weights[iNeuron];
        }
        delete [] synapticEvents;
        delete [] weights;
}
void TForm1::cNetwork::setDefaults()
{
        writeinfo = false;
        // neurons
        nNeuronTypes = 2;
        nSynapseTypes = 3;
        nOfNeuronType = 0;
        // nTypeDependents to 0
        affM = 0;
        affSD = 0;
        affLambda = 0;
        affIL = 0;
        affI0 = 0;
        affTau = 0;
        g = 0;
        gSd = 0;
        gL = 0;
        gLSD = 0;
        setNTypesDependent();
        // afferent input
        nEvents = 0;
        events = 0;
        nextPoi = 0;
        poiInput = 0;
        // general vals
        nNeurons = 0;
        neurons = 0;
        potentialHistory = 0;
        spikingHistory = 0;
        synapticEvents = 0;
        // explicit stimulation
        nStimulatedModules = 0;
        // time
        nSamples = 50;
        sample = 1; // start one step in
        samplingRate = 100;
        maxDelayInMsec = 10;
        // weight coding
        weights = 0;
        modules = new cModules;
        immunity = false;
}
void TForm1::cNetwork::run(AnsiString filename)
{
        baseName = filename;
        init();
        openFiles();
        while (step())
        {
                if (sample % ((nSamples) / 100) == 0)
                {
                        plotProgress(Form1->Image1, sample, nSamples);
                        Form1->Image1->Repaint();
                }
        }
        closeFiles();
}
void TForm1::cNetwork::openFiles()
{
        potentialHistory = new TFileStream(potentialHistoryName, fmCreate);
        spikingHistory = new TFileStream(spikingHistoryName, fmCreate);
        afferents = new TFileStream(afferentsName, fmCreate);
        infofile.open("infofile.txt");
}
void TForm1::cNetwork::closeFiles()
{
        delete potentialHistory;
        delete spikingHistory;
        delete afferents;
        infofile.close();
}
bool TForm1::cNetwork::step()
{
        leakAndIntegrate();
        fire();
        sample++;
        for (int i = 0; i < nNeurons; i++)
        {
                synapticEvents[i].shift();
        }
        if (sample >= nSamples)
        {
                sample = 1;
                return false;
        }
        else
        {
                return true;
        }
}
bool TForm1::cNetwork::leakAndIntegrate()
{
        float
                *allAff = new float[nNeurons],
                *allVm = new float[nNeurons];
        for (int iNeuron = 0; iNeuron < nNeurons; iNeuron++)
        {
                float
                        time = (float)sample * neurons[iNeuron].neuron->timeStep,
                        afferentInput = getAfferentInput(iNeuron, sample),
                        thisPotential;
//                afferents->Write(&afferentInput, sizeof(float));
                allAff[iNeuron] = afferentInput;
                int
                        *nSpikes = synapticEvents[iNeuron].nSpikes[0],
                        **source = synapticEvents[iNeuron].source[0];
                if (writeinfo)
                {
                        infofile << "lAI: " << iNeuron << " at " << sample << ": ";
                        infofile << "Vm = " << neurons[iNeuron].neuron->Vm << " ";
                        for (int i = 0; i < nSynapseTypes; i++)
                        {
                                infofile << "st: " << i << " ";
                                infofile << nSpikes[i] << " ";
                                for (int j = 0; j < nNeurons; j++)
                                {
                                        infofile << neurons[iNeuron].neuron->synapses->s[j][i] << " ";
                                }
                        }
                        infofile << endl;
                }
                thisPotential =
                        neurons[iNeuron].neuron->newMembranePotential(nSpikes,
                                source, time, afferentInput, weights[iNeuron]);
//                thisPotential =
//                        neurons[iNeuron].neuron->synapses.s[0][1];
//                potentialHistory->Write(&thisPotential, sizeof(thisPotential));
                allVm[iNeuron] = thisPotential;
        }
        afferents->Write(&allAff[0], nNeurons * sizeof(allAff[0]));
        delete [] allAff;
        potentialHistory->Write(&allVm[0], nNeurons * sizeof(allVm[0]));
        delete [] allVm;
        return true;
}
int TForm1::cNetwork::getNSynapseTypes()
{
        return nSynapseTypes;
}
int TForm1::cNetwork::getNNeuronTypes()
{
        return nNeuronTypes;
}
int TForm1::cNetwork::getType(int iNeuron)
{
        int
                type = -1,
                counter = 0;
        for (int t = 0; t < nNeuronTypes; t++)
        {
                counter += nOfNeuronType[t];
                if (counter > iNeuron)
                {
                        type = t;
                        break;
                }
        }
        return type;
}
float TForm1::cNetwork::getAfferentInput(int iNeuron, int iSample)
{
        int
                type = getType(iNeuron),
                iMod = modules->moduleOf(iNeuron);
        // updates Poissonian spike train and return current afferent input
        float
                thisAff = affI0[type];
        // 2. stimulation
        float
                stimCurrent = modules->stimulation[iMod].stimulation(iSample);
        thisAff += stimCurrent;
        // 3. Poissonian events
        if (iSample == nextPoi[iNeuron])
        {
                poiInput[iNeuron] += affIL[type];
                float
                        expRand;
                expRand = getExponentialRand(affLambda[type]);
                nextPoi[iNeuron] = iSample + 1 + expRand * samplingRate;
        }
        thisAff += poiInput[iNeuron];
        float
                dPoisson = (poiInput[iNeuron] / (affTau[type])) / samplingRate;
        poiInput[iNeuron] -= dPoisson;
        return thisAff;
}
bool TForm1::cNetwork::fire()
{
        float
                *allSpikes = new float[nNeurons];
        for (int iNeuron = 0; iNeuron < nNeurons; iNeuron++)
        {
                int
                        fromMod = modules->moduleOf(iNeuron);
                float
                        time = (float)sample * neurons[iNeuron].neuron->timeStep,
                        spike = neurons[iNeuron].neuron->fire(time);
//                spikingHistory->Write(&spike, sizeof(spike));
                allSpikes[iNeuron] = spike;
                if (spike == 0)
                {
                        continue;
                }
                if (writeinfo)
                {
                        infofile << endl << sample << " " << iNeuron << ", to " << endl;
                }
                for (int toNeuron = 0; toNeuron < nNeurons; toNeuron++)
                {
                        int
                                toMod = modules->moduleOf(toNeuron);
                        for (int synapseType = 0; synapseType < nSynapseTypes; synapseType++)
                        {
                                if (writeinfo)
                                {
                                        infofile << toNeuron << " st " << synapseType << "(w=" <<
                                                weights[toNeuron][iNeuron][synapseType];
//                                        infofile << ", g=" << neurons[toNeuron].neuron->synapses[iNeuron].g[iNeuron][synapseType] << ") ";
                                }
                                if (weights[toNeuron][iNeuron][synapseType] > 0)
                                {
                                        float
                                                mDelay = modules->delay[fromMod][toMod][synapseType],
                                                sdDelay = modules->delaysd[fromMod][toMod][synapseType],
                                                thisDelay = getNormalRand(mDelay, sdDelay);
                                        int
                                                dSample = 1 + thisDelay * samplingRate;
                                        if (dSample > maxDelayInSamples)
                                        {
                                                dSample = maxDelayInSamples;
                                        }
                                        int
                                                eventSample = sample + dSample;
                                        if (writeinfo)
                                        {
                                                infofile << " at " << eventSample << " ";
                                        }
                                        if (eventSample >= nSamples)
                                        {
                                                continue;
                                        }
                                        synapticEvents[toNeuron].add(dSample, synapseType, iNeuron);
                                }
                                if (writeinfo)
                                {
                                        infofile << endl;
                                }
                        }
                }
        }
        spikingHistory->Write(&allSpikes[0], nNeurons * sizeof(allSpikes[0]));
        delete [] allSpikes;
        return true;
}
void TForm1::cNetwork::plotProgress(TImage * & image, int s0, int nSamples)
{
        int
                x0 = image->Width / 2,
                y0 = image->Height / 2;
        image->Canvas->TextOut(x0, y0, IntToStr(s0) + " of " + IntToStr(nSamples));
}
void TForm1::cNetwork::plotHistory(TImage * & image, int sBegin, int sEnd,
        int mod0, int modend, bool savepic)
{
        image->Canvas->Brush->Color = clWhite;
        image->Canvas->FillRect(Rect(0, 0, image->Width, image->Height));
        int
                nModulesToPlot = 1 + modend - mod0;
        for (int iModule = mod0; iModule <= modend; iModule++)
        {
                int
                        subplotHeight = image->Height / nModulesToPlot,
                        x0 = 10,
                        y0 = (iModule - mod0) * subplotHeight;
                TImage
                        * subImage = new TImage(Form1);
                subImage->Width = image->Width;
                subImage->Height = subplotHeight;
                plotModule(subImage, iModule, sBegin, sEnd);
                image->Canvas->Draw(x0, y0, subImage->Picture->Bitmap);
        }
        if (savepic)
        {
                AnsiString
                        picName = baseName + ".bmp";
                image->Picture->SaveToFile(picName);
        }
}

void TForm1::cNetwork::plotModule(TImage * & image, int iModule, int sBegin, int sEnd)
{
        if (iModule < 0 | iModule >= modules->nModules |
                sBegin < 0 | sBegin >= nSamples |
                sEnd < 0 | sEnd >= nSamples |
                sBegin > sEnd)
        {
                return;
        }
        int
                margin = 10,
                nNeuronsInModule = modules->nMembers[iModule],
                nPlottedSamples = sEnd - sBegin;
        if (nNeuronsInModule * nPlottedSamples == 0)
        {
                return;
        }
        float
                subplotHeight = (float)image->Height / (float)nNeuronsInModule,
                subplotWidth = (float)image->Width - (float)(2 * margin),
                dx = (float)subplotWidth / (float)(nPlottedSamples),
                dy = (float)subplotHeight / 0.2; // -1 (s) or 0.2 (Vm), see leakAndIntegrate;
        // stimulation
        for (int iNeuron = 0; iNeuron < nNeuronsInModule; iNeuron++)
        {
                int
                        x0 = margin,
                        y0 = subplotHeight / 2 + (float)iNeuron * subplotHeight,
                        globalINeuron = modules->member(iNeuron, iModule);
                if (getType(globalINeuron) != 0)
                {
                        continue;
                }
                for (int iSample = 0; iSample < nPlottedSamples; iSample++)
                {
                        int
                                s = sBegin + iSample,
                                x = x0 + (int)(dx * (float)(iSample));
                        // stimu
                        if (modules->stimulation[iModule].stimulation(s) > 0)
                        {
                                image->Canvas->Brush->Color = clYellow;
                                image->Canvas->FillRect(Rect(x - 1, y0 - subplotHeight / 2, x + 0, y0 + subplotHeight / 2));
                        }
                        else if (modules->stimulation[iModule].stimulation(s) < 0)
                        {
                                image->Canvas->Brush->Color = clPurple;
                                image->Canvas->FillRect(Rect(x - 1, y0 - subplotHeight / 2, x + 0, y0 + subplotHeight / 2));
                        }
                        image->Canvas->Brush->Color = clWhite;
                }
        }
        // legend
        for (int iNeuron = 0; iNeuron < nNeuronsInModule; iNeuron++)
        {
                continue;
                int
                        x0 = margin,
                        y0 = (float)iNeuron * subplotHeight,
                        globalINeuron = modules->member(iNeuron, iModule);
                if (getType(globalINeuron) == 0)
                {
                        image->Canvas->Font->Color = clBlack;
                        image->Canvas->Brush->Color = clRed;
                }
                else
                {
                        image->Canvas->Font->Color = clBlack;
                        image->Canvas->Brush->Color = clBlue;
                }
                image->Canvas->TextOut(x0, y0, IntToStr(globalINeuron));
        }
        // potential
        // read potentialInput
        potentialHistory = new TFileStream(potentialHistoryName, fmOpenRead);
        float
                **potentialMatrix = new float*[nSamples];
        for (int iSample = 0; iSample < nSamples; iSample++)
        {
                potentialMatrix[iSample] = new float[nNeurons];
                potentialHistory->Read(&potentialMatrix[iSample][0], nNeurons * sizeof(float));
        }
        for (int iNeuron = 0; iNeuron < nNeuronsInModule; iNeuron++)
        {
                int
                        x0 = margin,
                        y0 = (float)iNeuron * subplotHeight,
                        globalINeuron = modules->member(iNeuron, iModule),
                        x1 = x0,
                        y1 = y0 - (int)(dy * potentialMatrix[0][globalINeuron]); // NB negative values
                for (int iSample = 0; iSample < nPlottedSamples; iSample++)
                {
                        int
                                s = sBegin + iSample,
                                x2 = x0 + (int)(dx * (float)(iSample)),
                                y2 = y0 - (int)(dy * potentialMatrix[s][globalINeuron]);
                        // potential
                        image->Canvas->Pen->Color = clBlack;
                        image->Canvas->MoveTo(x1, y1);
                        image->Canvas->LineTo(x2, y2);
                        x1 = x2;
                        y1 = y2;
                }
        }
        for (int iSample = 0; iSample < nSamples; iSample++)
        {
                delete [] potentialMatrix[iSample];
        }
        delete [] potentialMatrix;
        delete potentialHistory;
        // spikes
        // read spikingHistory
        spikingHistory = new TFileStream(spikingHistoryName, fmOpenRead);
        float
                **spikingMatrix = new float*[nSamples];
        for (int iSample = 0; iSample < nSamples; iSample++)
        {
                spikingMatrix[iSample] = new float[nNeurons];
                spikingHistory->Read(&spikingMatrix[iSample][0], nNeurons * sizeof(float));
        }
        for (int iNeuron = 0; iNeuron < nNeuronsInModule; iNeuron++)
        {
                int
                        x0 = margin,
                        y0 = subplotHeight / 2 + (float)iNeuron * subplotHeight,
                        globalINeuron = modules->member(iNeuron, iModule);
                for (int iSample = 0; iSample < nPlottedSamples; iSample++)
                {
                        int
                                s = sBegin + iSample,
                                x = x0 + (int)(dx * (float)(iSample));
                        // spike
                        image->Canvas->Pen->Color = clRed;
                        image->Canvas->Pen->Width = 1;
                        image->Canvas->MoveTo(x, y0);
                        if (spikingMatrix[s][globalINeuron] == 1)
                        {
                                image->Canvas->LineTo(x, y0 + 5);
                        }
                        image->Canvas->Pen->Width = 1;
                }
        }
        for (int iSample = 0; iSample < nSamples; iSample++)
        {
                delete [] spikingMatrix[iSample];
        }
        delete [] spikingMatrix;
        delete spikingHistory;
}

void TForm1::cNetwork::init()
{
        // clear previous structures
        clear();
        // inits for neurons, weights and afferents
        initNeurons();
        initFiles(); // init neurons must be called first
        initConductances();
        initHistory();
        initWeights();
        initAfferents();
}
void TForm1::cNetwork::initFiles()
{
        potentialHistoryName = baseName + ".pot";
        spikingHistoryName = baseName + ".spi";
        afferentsName = baseName + ".aff";
        infoFileName = baseName + ".inf";
        weightsFileName = baseName + ".wei";
        conductanceFileName = baseName + ".con";
        ofstream
                info;
        info.open(infoFileName.c_str());
        info << "nNeurons " << nNeurons << endl;
        info << "nSamples " << nSamples << endl;
        info << "nNeuronTypes " << nNeuronTypes << endl;
        info << "nSynapseTypes " << nSynapseTypes << endl;
        info << "Fs " << samplingRate << endl;
        info << "nModules " << modules->nModules << endl;
        for (int iM = 0; iM < modules->nModules; iM++)
        {
                for (int nt = 0; nt < nNeuronTypes; nt++)
                {
                        info << "nMembersOfType[" << nt << "][" << iM << "] " << modules->nMembersOfType[nt][iM] << endl;
                }
        }
        info.close();
}
void TForm1::cNetwork::initNeurons()
{
        // define number of nodes and type, define arrays
        nNeurons = 0;
        for (int iType = 0; iType < nNeuronTypes; iType++)
        {
                nNeurons += nOfNeuronType[iType];
        }
        neurons = new cNeuronHolder[nNeurons * 100];
        int
                index0 = 0;
        for (int iType = 0; iType < nNeuronTypes; iType++)
        {
                switch (iType)
                {
                        case 0:
                                for (int iNeuron = 0; iNeuron < nOfNeuronType[iType]; iNeuron++)
                                {
                                        neurons[index0 + iNeuron].neuron = new cPyramidalNeuron;
                                }
                                break;
                        case 1:
                                for (int iNeuron = 0; iNeuron < nOfNeuronType[iType]; iNeuron++)
                                {
                                        neurons[index0 + iNeuron].neuron = new cInhibitoryNeuron;
                                }
                                break;
                        default:
                                for (int iNeuron = 0; iNeuron < nOfNeuronType[iType]; iNeuron++)
                                {
                                        neurons[index0 + iNeuron].neuron = new cPyramidalNeuron;
                                }
                }
                index0 += nOfNeuronType[iType];
        }
        // initialize neurons
        for (int i = 0; i < nNeurons; i++)
        {
                int
                        *nSynapses = new int[nSynapseTypes],
                        thismod = modules->moduleOf(i),
                        neuronType = getType(i);
                for (int t = 0; t < nSynapseTypes; t++)
                {
                        nSynapses[t] = 0;
                        int
                                neuronType2 = 0;
                        if (t == 2)
                        {
                                neuronType2 = 1; // GABA-transmitting neurons
                        }
                        for (int iMod = 0; iMod < modules->nModules; iMod++)
                        {
                                int
                                        nInMod = modules->nMembersOfType[neuronType2][iMod],
                                        modRelation;
                                float
                                        p = modules->p[iMod][thismod][t];
                                if (iMod == thismod && neuronType == neuronType2) // don't correct for same neuron
                                {
                                        nInMod--;
                                }
                                nSynapses[t] += (float)nInMod * p;
                        }
                }
                neurons[i].neuron->init(samplingRate, nSynapseTypes, nNeurons, nSynapses);
                // random leakage conductance
                float
                        gLRand = getNormalRand(neurons[i].neuron->gL, 0.00001 * pow(10, -6));
                neurons[i].neuron->gL = gLRand;
                delete [] nSynapses;
        }
}
void TForm1::cNetwork::initHistory()
{
        // define and init histories; including synapticEvents which
        // will contain histories before they happen.
        potentialHistory = new TFileStream(potentialHistoryName, fmCreate);
        delete potentialHistory;
        spikingHistory = new TFileStream(spikingHistoryName, fmCreate);
        delete spikingHistory;
        maxDelayInSamples = ceil(maxDelayInMsec * 1000.0 / samplingRate);
        synapticEvents = new cSynapticEvent[nNeurons];
        for (int i = 0; i < nNeurons; i++)
        {
                synapticEvents[i].init(maxDelayInSamples, nSynapseTypes);
        }
}
void TForm1::cNetwork::emptyHistory()
{
        for (int i = 0; i < nNeurons; i++)
        {
                synapticEvents[i].init(nSamples, nSynapseTypes);
        }
}
void TForm1::cNetwork::setDelay(int modFrom, int modTo, int st, float delay, float delaysd)
{
        if (modules != 0)
        {
                modules->setDelay(modFrom, modTo, st, delay, delaysd);
                float
                        thisMax = delay + 3 * delaysd;
                if (thisMax > maxDelayInMsec)
                {
                        maxDelayInMsec = thisMax * 1000.0;
                }
        }
}
void TForm1::cNetwork::setConductance(int ntFrom, int ntTo, int st, float conductance, float condsd)
{
        if (!(ntFrom < 0 || ntFrom >= nNeuronTypes ||
                ntTo < 0 || ntTo >= nNeuronTypes ||
                st < 0 || st >= nSynapseTypes))
        {
                g[ntFrom][ntTo][st] = conductance;
                gSd[ntFrom][ntTo][st] = condsd;
        }
}
void TForm1::cNetwork::setLeakage(int nt, float conductance, float condsd)
{
        if (!(nt < 0 || nt >= nNeuronTypes))
        {
                gL[nt] = conductance;
                gLSD[nt] = condsd;
        }
}
void TForm1::cNetwork::initConductances()
{
        randomize();
        ofstream
                out;
        out.open(conductanceFileName.c_str());
        for (int i = 0; i < nNeurons; i++)
        {
                int
                        type_i = getType(i);
                float
                        leak = gL[type_i],
                        leaksd = gLSD[type_i];
                neurons[i].neuron->gL = getNormalRand(leak, leaksd) * pow(10.0, -6.0);
                out << i << " " << neurons[i].neuron->gL << endl;
                // in principle, there is a conductance between every neuron.
                // initWeights() builds more specific architectures.
                for (int j = 0; j < nNeurons; j++)
                {
                        int
                                type_j = getType(j);
                        for (int st = 0; st < nSynapseTypes; st++)
                        {
                                float
                                        cond = g[type_j][type_i][st],
                                        condsd = gSd[type_j][type_i][st];
                                neurons[i].neuron->synapses->g[j][st] = getNormalRand(cond, condsd) * pow(10.0, -6.0);
                                out << "(" << cond << ", " << condsd << ", " << neurons[i].neuron->synapses->g[j][st] << ") ";
                        }
                        out << endl;
                }
                out << endl;
        }
        out.close();
}
void TForm1::cNetwork::initWeights()
{
        // define and init weights
        randomize();
        ofstream
                out;
        weights = new float**[nNeurons]; // NB: to x from y: handier for leakAndIntegrate
        for (int i = 0; i < nNeurons; i++)
        {
                weights[i] = new float*[nNeurons];
                for (int j = 0; j < nNeurons; j++)
                {
                        weights[i][j] = new float[nSynapseTypes];
                }
        }
        for (int i = 0; i < nNeurons; i++)
        {
                for (int j = 0; j < nNeurons; j++)
                {
                        int
                                iMod = modules->moduleOf(i),
                                jMod = modules->moduleOf(j);
                        for (int k = 0; k < nSynapseTypes; k++)
                        {
                                float
                                        p = 1;
                                if (modules->nModules > 0)
                                {
                                        p = modules->p[iMod][jMod][k];
                                }
                                float
                                        die = (float)(rand() % 1000) / 1000.0,
                                        thisWeight;
                                bool
                                        excFrom = (i < nOfNeuronType[0]),
                                        exc_gaba = excFrom && (k == 2),
                                        inh_notGaba = (!excFrom) && (k != 2),
                                        toSelf = (i == j);
                                if ((exc_gaba || inh_notGaba || toSelf))
                                {
                                        thisWeight = 0;
                                }
                                else if (die < p)
                                {
                                        thisWeight = modules->w[iMod][jMod][k];
                                }
                                else
                                {
                                        thisWeight = 0;
                                }
                                weights[j][i][k] = thisWeight; // this orientation is needed later, in fire()
                        }
                }
        }
        out.open(weightsFileName.c_str());
        for (int k = 0; k < nSynapseTypes; k++)
        {
                for (int i = 0; i < nNeurons; i++)
                {
                        for (int j = 0; j < nNeurons; j++)
                        {
                                out << weights[i][j][k] << " "; // show from as col
                        }
                        out << endl;
                }
                out << endl << endl;
        }
        out.close();
}
float TForm1::cNetwork::gauss(float m, float sd, float a)
{
        if (sd == 0)
        {
                return 0;
        }
        float
                p = (1 / (2 * M_PI * sd)) * exp(-pow(a - m, 2.0) / sd);
        return p;
}
void TForm1::cNetwork::initAfferents()
{
        if (nextPoi != 0)
        {
                delete [] nextPoi;
        }
        if (poiInput != 0)
        {
                delete [] poiInput;
        }
        nextPoi = new int[nNeurons];
        poiInput = new float[nNeurons];
        for (int i = 0; i < nNeurons; i++)
        {
                poiInput[i] = 0;
                int
                        type = getType(i);
                float
                        expRand1 = getExponentialRand(affLambda[type]);
                nextPoi[i] = 1 + expRand1 * samplingRate;
        }
}
float TForm1::cNetwork::getNormalRand(float m, float sd, bool positive)
{
        if (sd == 0)
        {
                return m;
        }
        float
                v1,
                v2,
                rsq;
        v1 = (float)(rand() % 10000 + 1) / 10000.0;
        v2 = (float)(rand() % 10000 + 1) / 10000.0;
        float
                thisWay = sin(2 * M_PI * v1) * sqrt(-2 * log(v2));
        thisWay = m + thisWay * sd;
        if (positive)
        {
                if (thisWay < 0)
                {
                        thisWay = 0;
                }
        }
        return thisWay;
}
float TForm1::cNetwork::getPoissonRand(float m)
{
        // from the net; Knuth's Algorithm Q
        if (m == 0)
        {
                return 0;
        }
        float
                p = exp(-m),
                n = 0,
                q = 1;
        while(true)
        {
                float
                        u = (float)(rand() % 10001) / 10000.0;
                q *= u;
                if (q < p)
                {
                        break;
                }
                n++;
        }
        return q;
}
float TForm1::cNetwork::getExponentialRand(float m)
{
        if (m == 0)
        {
                return 0;
        }
        float
                u = (float)(rand() % 1000) / 1000.0,
                ev = -log(1.0 - u) / m; // assuming m * e ^ (-m * x) form, hence, mu == lambda
        return ev;
}
void TForm1::cNetwork::setNTypes(int anNeuronTypes, int anSynapseTypes)
{
        // neurons
        nNeuronTypes = anNeuronTypes;
        nSynapseTypes = anSynapseTypes;
        setNTypesDependent();
}
void TForm1::cNetwork::setNTypesDependent()
{
        if (nOfNeuronType != 0)
        {
                delete [] nOfNeuronType;
        }
        nOfNeuronType = new int[nNeuronTypes];
        for (int t = 0; t < nNeuronTypes; t++)
        {
                nOfNeuronType[t] = 0;
        }
        // afferents: input noise
        if (affM != 0)
        {
                delete [] affM;
                delete [] affSD;
        }
        if (affLambda != 0)
        {
                delete [] affLambda;
                delete [] affIL;
                delete [] affI0;
                delete [] affTau;
        }
        if (gL != 0)
        {
                delete [] gL;
                delete [] gLSD;
        }
        gL = new float[nNeuronTypes];
        gLSD = new float[nNeuronTypes];
        affM = new float[nNeuronTypes];
        affSD = new float[nNeuronTypes];
        affLambda = new float[nNeuronTypes];
        affIL = new float[nNeuronTypes];
        affI0 = new float[nNeuronTypes];
        affTau = new float[nNeuronTypes];
        for (int nt = 0; nt < nNeuronTypes; nt++)
        {
                gL[nt] = 0;
                gLSD[nt] = 0;
                affM[nt] = 0;
                affSD[nt] = 1;
                affLambda[nt] = 0;
                affIL[nt] = 0;
                affI0[nt] = 0;
                affTau[nt] = 1;
        }
        if (g != 0)
        {
                for (int nt = 0; nt < nNeuronTypes; nt++)
                {
                        for (int nt2 = 0; nt2 < nNeuronTypes; nt2++)
                        {
                                delete [] g[nt][nt2];
                        }
                        delete [] g[nt];
                }
                delete [] g;
        }
        g = new float**[nNeuronTypes];
        for (int nt = 0; nt < nNeuronTypes; nt++)
        {
                g[nt] = new float*[nNeuronTypes];
                for (int nt2 = 0; nt2 < nNeuronTypes; nt2++)
                {
                        g[nt][nt2] = new float[nSynapseTypes];
                        for (int st = 0; st < nSynapseTypes; st++)
                        {
                                g[nt][nt2][st] = 0;
                        }
                }
        }
        if (gSd != 0)
        {
                for (int nt = 0; nt < nNeuronTypes; nt++)
                {
                        for (int nt2 = 0; nt2 < nNeuronTypes; nt2++)
                        {
                                delete [] gSd[nt][nt2];
                        }
                        delete [] gSd[nt];
                }
                delete [] gSd;
        }
        gSd = new float**[nNeuronTypes];
        for (int nt = 0; nt < nNeuronTypes; nt++)
        {
                gSd[nt] = new float*[nNeuronTypes];
                for (int nt2 = 0; nt2 < nNeuronTypes; nt2++)
                {
                        gSd[nt][nt2] = new float[nSynapseTypes];
                        for (int st = 0; st < nSynapseTypes; st++)
                        {
                                gSd[nt][nt2][st] = 0;
                        }
                }
        }
}
void TForm1::cNetwork::setNNeurons(int iType, int N)
{
        nOfNeuronType[iType] = N;
}
void TForm1::cNetwork::setModules(int anModules, int * anMembers, int ** nMembersOfType,
        int ** amemberNeurons, float *apIn, float *apNext, float *apOut,
        int nSynapseTypes, int nNeuronTypes)
{
        modules->init(anModules, anMembers, nMembersOfType, amemberNeurons, apIn,
                apNext, apOut, nSynapseTypes, nNeuronTypes);
}
void TForm1::cNetwork::setT(int n, float r)
{
        nSamples = n;
        samplingRate = r;
}
void TForm1::cNetwork::setStimulation(int stimMod, int anEvents, int *start, int *stop, float *val)
{
        modules->setStimulation(stimMod, anEvents, start, stop, val);
}
void TForm1::cNetwork::setOscStimulation(int stimMod, int anFreqs, float *freq, float * duration, float *val)
{
        modules->setOscStimulation(stimMod, anFreqs, freq, duration, val, nSamples, samplingRate);
}
void TForm1::cNetwork::setArch(int mod1, int mod2, float * p)
{
        modules->setConnection(mod1, mod2, p);
}
void TForm1::cNetwork::setWeight(int mod1, int mod2, float * w)
{
        modules->setWeight(mod1, mod2, w);
}
void TForm1::cNetwork::reset()
{
        setDefaults();
        init();
}
int TForm1::cNetwork::getNSamples()
{
        return nSamples;
}
void TForm1::cNetwork::setA(float aaffLe, float aaffILe, float aaffI0e, float aaffTaue,
        float aaffLi, float aaffILi, float aaffI0i, float aaffTaui)
{
        affLambda[0] = aaffLe;
        affIL[0] = aaffILe * pow(10, -9);
        affI0[0] = aaffI0e * pow(10, -9);
        affTau[0] = aaffTaue * pow(10, -3);
        affLambda[1] = aaffLi;
        affIL[1] = aaffILi * pow(10, -9);
        affI0[1] = aaffI0i * pow(10, -9);
        affTau[1] = aaffTaui * pow(10, -3);
}
void TForm1::cNetwork::setImmunity(int arg)
{
        if (arg == 0)
        {
                immunity = false;
        }
        else
        {
                immunity = true;
        }
}

//---------------------------------------------------------------------------
TForm1::cParser::cParser()
{
        nCommands = 19;
        commands = new AnsiString[nCommands];
        commands[0] = "run";
        commands[1] = "n";
        commands[2] = "g";
        commands[3] = "mod";
        commands[4] = "reset";
        commands[5] = "t";
        commands[6] = "script";
        commands[7] = "plot";
        commands[8] = "a";
        commands[9] = "imm";
        commands[10] = "stim";
        commands[11] = "oscstim";
        commands[12] = "arch";
        commands[13] = "weight";
        commands[14] = "net";
        commands[15] = "saveplot";
        commands[16] = "normweights";
        commands[17] = "delay";
        commands[18] = "gL";
        lastCommand = "";
//        commandArray = &TForm1::cParser::run;
}
TForm1::cParser::~cParser()
{
        delete [] commands;
}
AnsiString TForm1::cParser::getLastCommand()
{
        return lastCommand;
}
AnsiString TForm1::cParser::perform(AnsiString input, cNetwork * & network, TImage * & image)
{
        lastCommand = input;
        AnsiString
                command = takeFirst(input),
                arguments = input,
                output = "Complete.";
        try
        {
        if (command == commands[0]) // run
        {
                output = run(network, arguments, image);
                network->plotHistory(image, 1, network->getNSamples() - 1, 0,
                        network->modules->nModules - 1, true);
        }
        else if (command == commands[1]) // n
        {
                setN(network, arguments, image);
        }
        else if (command == commands[2]) // g
        {
                setG(network, arguments, image);
        }
        else if (command == commands[3]) // mod
        {
                setModules(network, arguments, image);
        }
        else if (command == commands[4]) // reset
        {
                reset(network, arguments, image);
        }
        else if (command == commands[5]) // t
        {
                setT(network, arguments, image);
        }
        else if (command == commands[6]) // script
        {
                runScript(network, arguments, image);
        }
        else if (command == commands[7]) // plot
        {
                plot(network, arguments, image);
        }
        else if (command == commands[8]) // a
        {
                setA(network, arguments, image);
        }
        else if (command == commands[9]) // imm
        {
                setImmunity(network, arguments, image);
        }
        else if (command == commands[10]) // stim
        {
                setStimulation(network, arguments, image);
        }
        else if (command == commands[11]) // oscstim
        {
                setOscStimulation(network, arguments, image);
        }
        else if (command == commands[12]) // arch
        {
                setArch(network, arguments, image);
        }
        else if (command == commands[13]) // weight
        {
                setWeight(network, arguments, image);
        }
        else if (command == commands[14]) // net
        {
                setNet(network, arguments, image);
        }
        else if (command == commands[15]) // saveplot
        {
                savePlot(network, arguments, image);
        }
        else if (command == commands[16]) // normweights
        {
                network->modules->normalizeWeights();
        }
        else if (command == commands[17]) // delay
        {
                setDelay(network, arguments, image);
        }
        else if (command == commands[18]) // gL
        {
                setLeakage(network, arguments, image);
        }
        else
        {
                output = "Duh.";
        }
        }
        catch( ... )
        {
                output = "Processing error.";
        }
        return output;
}
AnsiString TForm1::cParser::run(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments);
        network->run(asarg1);
        return "Complete.";
}
AnsiString TForm1::cParser::reset(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        network->reset();
        return "Complete.";
}
AnsiString TForm1::cParser::setN(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments);
        int
                index = StrToInt(asarg1),
                val = StrToInt(asarg2);
        network->setNNeurons(index, val);
        return "Complete.";
}
AnsiString TForm1::cParser::setG(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments),
                asarg3 = takeFirst(arguments),
                asarg4 = takeFirst(arguments),
                asarg5 = takeFirst(arguments);
        int
                ntFrom = StrToInt(asarg1),
                ntTo = StrToInt(asarg2),
                st = StrToInt(asarg3);
        float
                conductance = StrToFloat(asarg4),
                condsd = StrToFloat(asarg5);
        network->setConductance(ntFrom, ntTo, st, conductance, condsd);
        return "Complete.";
}
AnsiString TForm1::cParser::setLeakage(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments),
                asarg3 = takeFirst(arguments);
        int
                nt = StrToInt(asarg1);
        float
                conductance = StrToFloat(asarg2),
                condsd = StrToFloat(asarg3);
        network->setLeakage(nt, conductance, condsd);
        return "Complete.";
}
AnsiString TForm1::cParser::setNet(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                message = "",
                asarg1 = takeFirst(arguments), // nNeuronTypes
                asarg2 = takeFirst(arguments); // nSynapseTypes
        int
                nNeuronTypes = StrToInt(asarg1),
                nSynapseTypes = StrToInt(asarg2);
        network->setNTypes(nNeuronTypes, nSynapseTypes);
        return message;
}
AnsiString TForm1::cParser::setModules(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        // nModules, nNeuronTypes, nSynapseTypes,
        // p (for all synapse types) nested in (in, next, out)
        // nOfType (for all types) nested in modules
        AnsiString
                message = "",
                asarg1 = takeFirst(arguments); // nModules
        int
                nNeuronTypes = network->getNNeuronTypes(),
                nSynapseTypes = network->getNSynapseTypes(),
                nModules = StrToInt(asarg1),
                *nMembers = new int[nModules],
                **memberNeurons = new int*[nModules],
                **nOfType = new int*[nNeuronTypes];
        float
                **p = new float*[3]; // in, next, out
        for (int t = 0; t < nNeuronTypes; t++)
        {
                nOfType[t] = new int[nModules];
        }
        for (int t = 0; t < 3; t++)
        {
                p[t] = new float[nSynapseTypes];
                for (int k = 0; k < nSynapseTypes; k++)
                {
                        AnsiString
                                asargp = takeFirst(arguments);
                        p[t][k] = StrToFloat(asargp);
                }
        }
        for (int iMod = 0; iMod < nModules; iMod++)
        {
                nMembers[iMod] = 0;
                for (int t = 0; t < nNeuronTypes; t++)
                {
                        AnsiString
                                asargNOfType = takeFirst(arguments);
                        if (asargNOfType == "")
                        {
                                message = "Too few arguments in mod command. ";
                        }
                        nOfType[t][iMod] = StrToInt(asargNOfType);
                        nMembers[iMod] += nOfType[t][iMod];
                }
        }
        // determine member neurons given [type 0, 1, ...] ordering
        int
                *totalN = new int[nNeuronTypes];
        for (int t = 0; t < nNeuronTypes; t++)
        {
                totalN[t] = 0;
                for (int iMod = 0; iMod < nModules; iMod++)
                {
                        totalN[t] += nOfType[t][iMod];
                }
        }
        for (int iMod = 0; iMod < nModules; iMod++)
        {
                memberNeurons[iMod] = new int[nMembers[iMod]];
                // determine member neurons given [neuronType 0, 1, ...] ordering
                int
                        membIndex = 0,
                        index0Type = 0;
                for (int t = 0; t < nNeuronTypes; t++)
                {
                        int
                                prev = 0;
                        for (int prevMod = 0; prevMod < iMod; prevMod++)
                        {
                                prev += nOfType[t][prevMod];
                        }
                        for (int memb = 0; memb < nOfType[t][iMod]; memb++)
                        {
                                memberNeurons[iMod][membIndex] = index0Type + prev + memb;
                                membIndex++;
                        }
                        index0Type += totalN[t]; // skip to next type
                }
        }
        AnsiString
                test = takeFirst(arguments); // should be empty
        if (test != "")
        {
                message = "Too many arguments in mod command. ";
        }
        for (int t = 0; t < nNeuronTypes; t++)
        {
                network->setNNeurons(t, totalN[t]);
        }
        delete [] totalN;
        network->setModules(nModules, nMembers, nOfType, memberNeurons,
                p[0], p[1], p[2], nSynapseTypes, nNeuronTypes);
        return message;
}
AnsiString TForm1::cParser::setT(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments);
        int
                arg1 = StrToInt(asarg1);
        float
                arg2 = StrToFloat(asarg2);
        network->setT(arg1, arg2);
        return "Complete.";
}
AnsiString TForm1::cParser::setDelay(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments),
                asarg3 = takeFirst(arguments),
                asarg4 = takeFirst(arguments),
                asarg5 = takeFirst(arguments);
        int
                modFrom = StrToInt(asarg1),
                modTo = StrToInt(asarg2),
                st = StrToInt(asarg3);
        float
                delay = StrToFloat(asarg4),
                delaysd = StrToFloat(asarg5);
        network->setDelay(modFrom, modTo, st, delay, delaysd);
        return "Complete.";
}
AnsiString TForm1::cParser::setStimulation(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments);
        int
                iMod = StrToInt(asarg1),
                nEvents = StrToInt(asarg2),
                *start = new int[nEvents],
                *stop = new int[nEvents];
        float
                *val = new float[nEvents];
        for (int e = 0; e < nEvents; e++)
        {
                AnsiString
                        asarg1 = takeFirst(arguments),
                        asarg2 = takeFirst(arguments),
                        asarg3 = takeFirst(arguments);
                start[e] = StrToInt(asarg1);
                stop[e] = StrToInt(asarg2);
                val[e] = StrToFloat(asarg3);
        }
        network->setStimulation(iMod, nEvents, start, stop, val);
        // deletions done by cStimulation
        return "Complete.";
}
AnsiString TForm1::cParser::setOscStimulation(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments);
        int
                iMod =   StrToInt(asarg1),
                nFreqs = StrToInt(asarg2);
        float
                *freq = new float[nFreqs],
                *duration = new float[nFreqs],
                *val = new float[nFreqs];
        for (int e = 0; e < nFreqs; e++)
        {
                AnsiString
                        asarg1 = takeFirst(arguments),
                        asarg2 = takeFirst(arguments),
                        asarg3 = takeFirst(arguments);
                freq[e] = StrToFloat(asarg1);
                duration[e] = StrToFloat(asarg2);
                val[e] = StrToFloat(asarg3);
        }
        network->setOscStimulation(iMod, nFreqs, freq, duration, val);
        // deletions done by cStimulation
        return "Complete.";
}
AnsiString TForm1::cParser::setArch(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        // mod must be run first
        AnsiString
                message = "",
                asM1 = takeFirst(arguments),
                asM2 = takeFirst(arguments);
        int
                mod1 = StrToInt(asM1),
                mod2 = StrToInt(asM2),
                nSynapseTypes = network->getNSynapseTypes();
        float
                *p = new float[nSynapseTypes];
        for (int t = 0; t < nSynapseTypes; t++)
        {
                AnsiString
                        asP = takeFirst(arguments);
                if (asP == "")
                {
                        message = "Too few arguments in arch command. ";
                        break;
                }
                p[t] = StrToFloat(asP);
        }
        AnsiString
                test = takeFirst(arguments);
        if (test != "")
        {
                message = "Too many arguments in arch command. ";
        }
        network->setArch(mod1, mod2, p);
        delete [] p;
        return message;
}
AnsiString TForm1::cParser::setWeight(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        // mod must be run first
        AnsiString
                message = "",
                asM1 = takeFirst(arguments),
                asM2 = takeFirst(arguments);
        int
                mod1 = StrToInt(asM1),
                mod2 = StrToInt(asM2),
                nSynapseTypes = network->getNSynapseTypes();
        float
                *p = new float[nSynapseTypes];
        for (int t = 0; t < nSynapseTypes; t++)
        {
                AnsiString
                        asP = takeFirst(arguments);
                if (asP == "")
                {
                        message = "Too few arguments in arch command. ";
                        break;
                }
                p[t] = StrToFloat(asP);
        }
        AnsiString
                test = takeFirst(arguments);
        if (test != "")
        {
                message = "Too many arguments in arch command. ";
        }
        network->setWeight(mod1, mod2, p);
        delete [] p;
        return message;
}
AnsiString TForm1::cParser::runScript(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments);
        ifstream
                in;
        in.open(asarg1.c_str());
        if (!in.is_open())
        {
                return "File not found.";
        }
        while (true)
        {
                char
                        line[255];
                in.getline(line, 255);
                if (in.eof() || line == "")
                {
                        break;
                }
                perform(line, network, image);
        }
        in.close();
        return "Complete.";
}
AnsiString TForm1::cParser::plot(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments),
                asarg2 = takeFirst(arguments),
                asarg3 = takeFirst(arguments),
                asarg4 = takeFirst(arguments);
        if (asarg1 == ".")
        {
                asarg1 = "0";
        }
        if (asarg2 == ".")
        {
                asarg2 = IntToStr(network->getNSamples() - 1);
        }
        if (asarg3 == ".")
        {
                asarg3 = "0";
        }
        if (asarg4 == ".")
        {
                asarg4 = IntToStr(network->modules->nModules - 1);
        }
        int
                arg1 = StrToInt(asarg1),
                arg2 = StrToInt(asarg2),
                arg3 = StrToInt(asarg3),
                arg4 = StrToInt(asarg4);
        network->plotHistory(image, arg1, arg2, arg3, arg4, false);
        return "Complete.";
}
AnsiString TForm1::cParser::savePlot(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments);
        image->Picture->SaveToFile(asarg1);
        return "Complete.";
}
AnsiString TForm1::cParser::setA(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        // input in Hz, nA and msec. Taken from Wang (1999)
        // initAfferents corrects for samplingRate 
        AnsiString
                asarg5 = takeFirst(arguments),
                asarg6 = takeFirst(arguments),
                asarg7 = takeFirst(arguments),
                asarg8 = takeFirst(arguments),
                asarg9 = takeFirst(arguments),
                asarg10 = takeFirst(arguments),
                asarg11 = takeFirst(arguments),
                asarg12 = takeFirst(arguments);
        float
                arg5 = StrToFloat(asarg5),
                arg6 = StrToFloat(asarg6),
                arg7 = StrToFloat(asarg7),
                arg8 = StrToFloat(asarg8),
                arg9 = StrToFloat(asarg9),
                arg10 = StrToFloat(asarg10),
                arg11 = StrToFloat(asarg11),
                arg12 = StrToFloat(asarg12);
        network->setA(arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12);
        return "Complete.";
}
AnsiString TForm1::cParser::setImmunity(cNetwork * & network, AnsiString arguments, TImage * & image)
{
        AnsiString
                asarg1 = takeFirst(arguments);
        int
                arg1 = StrToFloat(asarg1);
        network->setImmunity(arg1);
        return "Complete.";
}

AnsiString TForm1::cParser::takeFirst(AnsiString & input)
{
        input = input.Trim();
        if (input.AnsiPos(" ") == 0)
        {
                return input;
        }
        else
        {
                AnsiString
                        first = input.SubString(1, input.AnsiPos(" ") - 1);
                input = input.SubString(input.AnsiPos(" ") + 1, input.Length());
                return first;
        }
}
//---------------------------------------------------------------------------
TForm1::cWorld::cWorld()
{
        network = new cNetwork;
        parser = new cParser;
}

TForm1::cWorld::~cWorld()
{
        delete network;
        delete parser;
}

//---------------------------------------------------------------------------
void __fastcall TForm1::eInputKeyPress(TObject *Sender, char &Key)
{
        if (IntToStr(Key) == 13)
        {
                InfoLabel->Caption = "Performing command " + eInput->Text + "...";
                Repaint();
                InfoLabel->Caption = world.parser->perform(eInput->Text, world.network, Image1);
                eInput->Text = "";
                Repaint();
        }
}

void __fastcall TForm1::FormShow(TObject *Sender)
{
        eInput->SetFocus();
}

void __fastcall TForm1::Save1Click(TObject *Sender)
{
        SaveDialog1->Title = "Save current picture as...";
        SaveDialog1->DefaultExt = "bmp";
        if (SaveDialog1->Execute())
        {
                Image1->Picture->SaveToFile(SaveDialog1->FileName);
        }
}

void __fastcall TForm1::bScriptClick(TObject *Sender)
{
        InfoLabel->Caption = "Running script.txt...";
        Repaint();
        eInput->Text = "script script.txt";
        InfoLabel->Caption = world.parser->perform(eInput->Text, world.network, Image1);
        eInput->Text = "";
        Repaint();
}
//---------------------------------------------------------------------------

