//---------------------------------------------------------------------------

#ifndef uMainH
#define uMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <math.h>
#include <fstream.h>
#include <Dialogs.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TLabel *InfoLabel;
        TImage *Image1;
        TEdit *eInput;
        TMainMenu *MainMenu1;
        TMenuItem *Picture1;
        TMenuItem *Save1;
        TSaveDialog *SaveDialog1;
        TButton *bScript;
        void __fastcall eInputKeyPress(TObject *Sender, char &Key);
        void __fastcall FormShow(TObject *Sender);
        void __fastcall Save1Click(TObject *Sender);
        void __fastcall bScriptClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
        class cSynapse
        {
                public:
                        cSynapse();
                        ~cSynapse();
                        float
                                epsQuick,
                                VE,
                                VI,
                                Mg,
                                **g,
                                phi,
                                alphaX,
                                alphaS,
                                alphaI,
                                *tauX,
                                *tauS,
                                **x,
                                **s,
                                *xDecay,
                                *sDecay,
                                *tauSInv;
                        int
                                nSynapsesTotal,
                                nSynapseTypes,
                                *nSynapses;
                        void setDefaults(float timeStep);
                        void clear();
                        void init(int anSynapsesTotal, int Types,
                                int *anSynapses, float timeStep);
                        float integrateAMPASpike(int iSynapse, float Vm, float timeStep, bool spike, int type);
                        float integrateNMDASpike(int iSynapse, float Vm, float timeStep, bool spike, int type);
                        float integrateGABASpike(int iSynapse, float Vm, float timeStep, bool spike, int type);
        };
        class cAbstractNeuron
        {
                public:
                        cAbstractNeuron();
                        ~cAbstractNeuron();
                        cSynapse
                                *synapses;
                        float
                                Vm,
                                VL,
                                Vth,
                                Vreset,
                                Cm,
                                gL,
                                tauM,
                                tauRef,
                                lastSpikeTime,
                                timeStep;
                        bool
                                spiking;
                        int
                                nNeurons,
                                nSynapses,
                                nSynapseTypes;
                        void init(float samplingRate, int nSynapseTypes,
                                int nNeurons, int * nSynapses);
                        virtual void setDefaults();
                        void adjustTimeConstants(float samplingRate);
                        float newMembranePotential(int *nSpikes,
                                int ** source, float time, float afferent,
                                float ** & weights);
                        float leakage();
                        float integrateInputs(int *nSpikes,
                                int ** source, float afferent, float ** & weights);
                        float integrateAMPAInputs(int nAMPASpikes, int *AMPASource,
                                int type, float ** & weights);
                        float integrateNMDAInputs(int nNMDASpikes, int *NMDASource,
                                int type, float ** & weights);
                        float integrateGABAInputs(int nGABASpikes, int *GABASource,
                                int type, float ** & weights);
                        float fire(float time);
        };
        class cPyramidalNeuron : public cAbstractNeuron
        {
                public:
                        cPyramidalNeuron();
                        ~cPyramidalNeuron();
        };
        class cInhibitoryNeuron : public cAbstractNeuron
        {
                public:
                        cInhibitoryNeuron();
                        ~cInhibitoryNeuron();
                        void setInhibitoryDefaults();
        };
        class cNeuronHolder
        {
                public:
                        cNeuronHolder();
                        ~cNeuronHolder();
                        cAbstractNeuron
                                *neuron;
        };
        class cSynapticEvent
        {
                public:
                        cSynapticEvent();
                        ~cSynapticEvent();
                        void clear();
                        void init(int awindowLength, int anSynapseTypes);
                        int add(int delay, int synapseType, int source);
                        void shift();
                        int
                                windowLength,
                                nSynapseTypes,
                                **nSpikes,
                                ***source;
        };
        class cStimulation
        {
                public:
                        cStimulation();
                        ~cStimulation();
                        int
                                iMod,
                                nEvents,
                                *start,
                                *stop;
                        float
                                *val;
                        void init(int anEvents, int *astart, int *astop, float *aval);
                        void initOsc(int anFreqs, float * freq, float * duration, float *aval,
                                int nSamples, float samplingRate);
                        float stimulation(int sample);
        };
        class cModules
        {
                public:
                        cModules();
                        ~cModules();
                        cStimulation
                                *stimulation;
                        int
                                maxDelaySamples,
                                nModules,
                                nNeuronTypes,
                                nSynapseTypes,
                                *nMembers,
                                **nMembersOfType, // iMod, neuronType
                                **memberNeurons;
                        float
                                *pIn,
                                *pNext,
                                *pOut,
                                ***delay,
                                ***delaysd,
                                ***p,
                                ***w;
                        void init(int anModules, int * anMembers,
                                int ** nMembersOfType, int ** amemberNeurons,
                                float *apIn, float *apNext, float *apOut,
                                int nSynapseTypes, int nNeuronTypes);
                        void clear();
                        bool setConnection(int mod1, int mod2, float *p);
                        bool setWeight(int mod1, int mod2, float *p);
                        int moduleOf(int iNeuron);
                        int member(int iMember, int iModule);
                        void setStimulation(int iMod, int anEvents, int *start,
                                int *stop, float *val);
                        void setOscStimulation(int iMod, int anFreqs, float *freq,
                                float * duration, float *val, int nSamples,
                                float samplingRate);
                        void normalizeWeights();
                        void setDelay(int modFrom, int modTo, int st, float delay, float delaysd);
        };
        class cNetwork
        {
                public:
                        cNetwork();
                        ~cNetwork();
                        cSynapticEvent
                                *synapticEvents;
                        cModules
                                *modules;
                        void run(AnsiString filename);
                        void plotHistory(TImage * & image, int sBegin, int sEnd,
                                int mod0, int modend, bool savepic);
                        // interface functions
                        // set
                        void setNTypes(int anNeuronTypes, int anSynapseTypes);
                        void setNNeurons(int iType, int N);
                        void setModules(int anModules, int * anMembers, int ** nMembersOfType,
                                int ** amemberNeurons, float *apIn, float *apNext,
                                float *apOut, int nSynapseTypes, int nNeuronTypes);
                        void setT(int n, float r);
                        void setA(float aaffLe, float aaffILe, float aaffI0e, float aaffTaue,
                                float aaffLi, float aaffILi, float aaffI0i, float aaffTaui);
                        void setStimulation(int iMod, int anEvents, int *start,
                                int *stop, float *val);
                        void setOscStimulation(int iMod, int anFreqs, float *freq, float * duration, float *val);
                        void setArch(int mod1, int mod2, float * p);
                        void setDelay(int modFrom, int modTo, int st, float delay, float delaysd);
                        void setConductance(int ntFrom, int ntTo, int st, float cond, float condsd);
                        void setLeakage(int nt, float cond, float condsd);
                        void setWeight(int mod1, int mod2, float * p);
                        void setImmunity(int arg);
                        void reset();
                        // get
                        int getNSamples();
                        int getNSynapseTypes();
                        int getNNeuronTypes();
                private:
                        bool
                                writeinfo;
                        AnsiString
                                baseName,
                                potentialHistoryName,
                                spikingHistoryName,
                                afferentsName,
                                infoFileName,
                                weightsFileName,
                                conductanceFileName;
                        TFileStream
                                *potentialHistory,
                                *spikingHistory,
                                *afferents;
                        ofstream
                                infofile;
                        bool
                                immunity;
                        int
                                nSamples,
                                sample,
                                nNeuronTypes,
                                nSynapseTypes,
                                nNeurons,
                                *nOfNeuronType,
                                maxDelayInSamples,
                                nHistogramBins,
                                nEvents,
                                *events,
                                *nextPoi,
                                nStimulatedModules;
                        float
                                samplingRate,
                                ***g,
                                *gL,
                                ***gSd,
                                *gLSD,
                                ***weights,
                                **affDistribution,
                                *affM,
                                *affSD,
                                *affLambda,
                                *affIL,
                                *affI0,
                                *affTau,
                                *poiInput,
                                maxDelayInMsec;
                        cNeuronHolder
                                *neurons;
                        void setDefaults();
                        void setNTypesDependent();
                        void init();
                        void initFiles();
                        void initNeurons();
                        void initHistory();
                        void initConductances();
                        void initWeights();
                        void initAfferents();
                        bool step();
                        bool leakAndIntegrate();
                        bool fire();
                        void plotModule(TImage * & image, int iModule, int sBegin, int sEnd);
                        void plotProgress(TImage * & image, int s0, int nSamples);
                        void emptyHistory();
                        void clear();
                        float gauss(float m, float sd, float a);
                        float getNormalRand(float m, float sd, bool positive = true);
                        float getPoissonRand(float m);
                        float getExponentialRand(float m);
                        float getAfferentInput(int iNeuron, int iSample);
                        int getType(int iNeuron);
                        void openFiles();
                        void closeFiles();
        };
        class cParser
        {
                public:
                        cParser();
                        ~cParser();
                        AnsiString perform(AnsiString input, cNetwork * & network,
                                TImage * & image);
                        AnsiString getLastCommand();
                        AnsiString (*commandArray) (cNetwork * & network, AnsiString arguments, TImage * & image);
                private:
                        int
                                nCommands;
                        AnsiString
                                lastCommand,
                                *commands;
                        AnsiString takeFirst(AnsiString & line);
                        AnsiString run(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString reset(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setN(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setG(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setLeakage(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setModules(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setT(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString runScript(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString plot(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setA(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setStimulation(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setOscStimulation(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setArch(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setWeight(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setNet(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setDelay(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString setImmunity(cNetwork * & network, AnsiString arguments, TImage * & image);
                        AnsiString savePlot(cNetwork * & network, AnsiString arguments, TImage * & image);
        };
        class cWorld
        {
                public:
                        cWorld();
                        ~cWorld();
                        cParser
                                *parser;
                        cNetwork
                                *network;
        };
        cWorld
                world;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
